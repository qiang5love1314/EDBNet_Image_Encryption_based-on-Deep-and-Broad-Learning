# RIE-RID
Robust Image Encryption With Scanning Technology, the El-Gamal Algorithm and Chaos Theory.

Based on the paper (aug 12,2020) by

SURA F. YOUSIF1 (Member, IEEE),  ALI J. ABBOUD AND HUSSEIN Y. RADHI.

Published by IEEE.

This encryption method works for b/w or color image of any dimensions. 
