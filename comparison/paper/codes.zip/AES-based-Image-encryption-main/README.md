# AES-based-Image-encryption
An image encryption method based on chaos system and AES algorithm
