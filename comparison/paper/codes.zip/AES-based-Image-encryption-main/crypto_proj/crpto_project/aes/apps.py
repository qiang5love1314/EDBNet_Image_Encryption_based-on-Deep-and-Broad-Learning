from django.apps import AppConfig


class AesConfig(AppConfig):
    name = 'aes'
