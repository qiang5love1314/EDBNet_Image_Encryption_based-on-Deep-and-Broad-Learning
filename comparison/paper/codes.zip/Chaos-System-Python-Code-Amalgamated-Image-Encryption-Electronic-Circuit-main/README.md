# Chaos-System-Python-Code-Amalgamated-Image-Encryption-Electronic-Circuit
This repository contains my latest chaotic system research based python codes and its electronic realization file. The files in this repo are:

1. A novel concept of Amalagamated Image Encryption
2. Memristor attached to Lorentz-Stenflo Chaotic system (Python Codes)
3. Multisim File for Memristive Based Lorentz-Stenflo Chaotic system 
